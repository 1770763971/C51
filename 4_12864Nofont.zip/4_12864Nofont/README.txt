CODE: user's code in it
IAR:    iar's project
MDK:keil's project
USER:Main function and Interrupt function
